<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables
$id = $_GET['id'] ?? '';
$message = '';
$error = '';

// Iniciar sesión
session_start();

// Verificar autenticación
if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    header("Location: authenticate2.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

// Obtener los datos del contacto
if ($id) {
    $sql = "SELECT * FROM contactos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $contact = $result->fetch_assoc();

    if (!$contact) {
        die("Contacto no encontrado.");
    }
} else {
    die("ID de contacto no proporcionado.");
}

// Procesar el formulario de edición
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_empresa = $conn->real_escape_string($_POST['nombre_empresa']);
    $rubro = $conn->real_escape_string($_POST['rubro']);
    $telefono = $conn->real_escape_string($_POST['telefono']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $direccion = $conn->real_escape_string($_POST['direccion']);
    $web = $conn->real_escape_string($_POST['web']);

    $sql = "UPDATE contactos SET nombre_empresa = ?, rubro = ?, telefono = ?, correo = ?, direccion = ?, web = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssssi', $nombre_empresa, $rubro, $telefono, $correo, $direccion, $web, $id);

    if ($stmt->execute()) {
        $message = "Contacto actualizado exitosamente.";
        header("Refresh: 2; url=contactos.php"); // Redirigir después de 2 segundos
    } else {
        $error = "Error: " . $conn->error;
    }
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Contacto</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?php include "includes/header.php"; ?>

    <main>
        <h1>Editar Contacto</h1>

        <?php if ($message): ?>
            <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Formulario de edición de contacto -->
        <form method="POST" action="cont_edit.php?id=<?php echo $id; ?>">
            <label for="nombre_empresa">Nombre de la Empresa:</label>
            <input type="text" name="nombre_empresa" id="nombre_empresa" value="<?php echo htmlspecialchars($contact['nombre_empresa']); ?>" required>

            <label for="rubro">Rubro:</label>
            <input type="text" name="rubro" id="rubro" value="<?php echo htmlspecialchars($contact['rubro']); ?>" required>

            <label for="telefono">Teléfono:</label>
            <input type="text" name="telefono" id="telefono" value="<?php echo htmlspecialchars($contact['telefono']); ?>" required>

            <label for="correo">Correo:</label>
            <input type="email" name="correo" id="correo" value="<?php echo htmlspecialchars($contact['correo']); ?>" required>

            <label for="direccion">Dirección:</label>
            <input type="text" name="direccion" id="direccion" value="<?php echo htmlspecialchars($contact['direccion']); ?>">

            <label for="web">Web:</label>
            <input type="text" name="web" id="web" value="<?php echo htmlspecialchars($contact['web']); ?>">

            <button type="submit">Actualizar Contacto</button>
        </form>
    </main>
</body>
</html>
