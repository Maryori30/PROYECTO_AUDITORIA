<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables
$id = $_GET['id'] ?? '';
$message = '';
$error = '';

// Iniciar sesión
session_start();

// Verificar autenticación
if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    header("Location: authenticate.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

// Obtener los datos del cliente
if ($id) {
    $sql = "SELECT * FROM clientes WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $client = $result->fetch_assoc();

    if (!$client) {
        die("Cliente no encontrado.");
    }
} else {
    die("ID de cliente no proporcionado.");
}

// Procesar el formulario de edición
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombres = $conn->real_escape_string($_POST['nombres']);
    $apellidos = $conn->real_escape_string($_POST['apellidos']);
    $dni_ruc = $conn->real_escape_string($_POST['dni_ruc']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $edad = $conn->real_escape_string($_POST['edad']);
    $celular = $conn->real_escape_string($_POST['celular']);
    $direccion = $conn->real_escape_string($_POST['direccion']);

    $sql = "UPDATE clientes SET nombres = ?, apellidos = ?, dni_ruc = ?, correo = ?, edad = ?, celular = ?, direccion = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssssssi', $nombres, $apellidos, $dni_ruc, $correo, $edad, $celular, $direccion, $id);

    if ($stmt->execute()) {
        $message = "Cliente actualizado exitosamente.";
        header("Refresh: 2; url=clientes.php"); // Redirigir después de 2 segundos
    } else {
        $error = "Error: " . $conn->error;
    }
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cliente</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<?php include "includes/header.php"; ?>

    <main>
        <h1>Editar Cliente</h1>

        <?php if ($message): ?>
            <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Formulario de edición de cliente -->
        <form method="POST" action="c_edit.php?id=<?php echo $id; ?>">
            <label for="nombres">Nombres:</label>
            <input type="text" name="nombres" id="nombres" value="<?php echo htmlspecialchars($client['nombres']); ?>" required>

            <label for="apellidos">Apellidos:</label>
            <input type="text" name="apellidos" id="apellidos" value="<?php echo htmlspecialchars($client['apellidos']); ?>" required>

            <label for="dni_ruc">DNI/RUC:</label>
            <input type="text" name="dni_ruc" id="dni_ruc" value="<?php echo htmlspecialchars($client['dni_ruc']); ?>" required>

            <label for="correo">Correo:</label>
            <input type="email" name="correo" id="correo" value="<?php echo htmlspecialchars($client['correo']); ?>" required>

            <label for="edad">Edad:</label>
            <input type="number" name="edad" id="edad" value="<?php echo htmlspecialchars($client['edad']); ?>" required>

            <label for="celular">Celular:</label>
            <input type="text" name="celular" id="celular" value="<?php echo htmlspecialchars($client['celular']); ?>" required>

            <label for="direccion">Dirección:</label>
            <input type="text" name="direccion" id="direccion" value="<?php echo htmlspecialchars($client['direccion']); ?>" required>

            <button type="submit">Actualizar Cliente</button>
        </form>
    </main>
</body>
</html>
