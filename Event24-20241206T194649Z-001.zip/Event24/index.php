<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables para búsqueda
$search_event = '';
$search_client = '';
$search_date = '';

// Procesar búsqueda si se envía el formulario
if (isset($_GET['search_event'])) {
    $search_event = $conn->real_escape_string($_GET['search_event']);
}

if (isset($_GET['search_client'])) {
    $search_client = $conn->real_escape_string($_GET['search_client']);
}

if (isset($_GET['search_date'])) {
    $search_date = $conn->real_escape_string($_GET['search_date']);
}

// Condiciones para búsqueda
$where_conditions = [];

// Buscar por nombre de evento
if (!empty($search_event)) {
    $where_conditions[] = "eventos.nombre_evento LIKE '%$search_event%'";
}

// Buscar por cliente
if (!empty($search_client)) {
    $where_conditions[] = "clientes.dni_ruc LIKE '%$search_client%'";
}

// Buscar por fecha
if (!empty($search_date)) {
    $where_conditions[] = "eventos.fecha LIKE '%$search_date%'";
}

// Si no hay búsqueda específica, ocultar eventos pasados y del cliente '00000000'
if (empty($search_event) && empty($search_client) && empty($search_date)) {
    $where_conditions[] = "eventos.fecha >= NOW()";
    $where_conditions[] = "clientes.dni_ruc != '00000000'";
}

// Construir la consulta SQL
$sql = "SELECT eventos.*, clientes.nombres AS cliente_nombre 
        FROM eventos 
        JOIN clientes ON eventos.cliente_id = clientes.id";

// Añadir las condiciones de búsqueda si existen
if (!empty($where_conditions)) {
    $sql .= " WHERE " . implode(' AND ', $where_conditions);
}

// Ordenar los eventos por fecha ascendente
$sql .= " ORDER BY eventos.fecha ASC";

// Ejecutar la consulta
$result = $conn->query($sql);

// SQL para obtener eventos próximos, excluyendo eventos pasados y eventos del cliente con DNI/RUC '00000000'
$upcoming_events_sql = "SELECT eventos.*, clientes.nombres AS cliente_nombre 
                        FROM eventos 
                        JOIN clientes ON eventos.cliente_id = clientes.id 
                        WHERE eventos.fecha >= NOW() 
                        AND clientes.dni_ruc != '00000000'
                        ORDER BY eventos.fecha ASC LIMIT 5";
$upcoming_events_result = $conn->query($upcoming_events_sql);

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Eventos</title>
    <link rel="stylesheet" href="css/stclientes.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        /* 
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
    margin: 0;
    padding: 0;
} */

/* Estilos del contenedor principal */
main {
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Barra de búsqueda */
.search-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 20px;
}

.search-container input[type="text"],
.search-container input[type="date"] {
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    width: 100%;
    max-width: 250px;
}

.search-container .new-event-button {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgb(233, 228, 228);
    border-radius: 50%;
    padding: 10px;
    color: #fff;
    text-decoration: none;
    font-size: 16px;
}

.new-event-button:hover {
    background-color: #2b44d2;
}

.search-container .new-event-button img {
    width: 30px;
    height: auto;
}


/* Estilos de la tabla */
/* table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 12px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
} */

tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

tbody tr:hover {
    background-color: #f1f1f1;
}

/* Estilos de los botones de acción */
.action-button {
    display: inline-block;
    padding: 8px 12px;
    margin-right: 5px;
    border-radius: 4px;
    text-decoration: none;
    color: #fff;
    font-weight: bold;
    text-align: center;
}

.action-button.detail {
    background-color: #28a745;
    width: 76px;
}

.action-button.edit {
    background-color: #007bff;
    width: 76px;
}

.action-button.delete {
    background-color: #dc3545;
    width: 76px;
}

/* Estilos de la sección de eventos próximos */
.upcoming-events {
    margin-top: 30px;
    
}

/* Estilo para el título de la sección */
.upcoming-events h2 {
    font-size: 24px;
    margin-bottom: 15px;
}

/* Estilo para el contenedor de los eventos próximos */
.upcoming-events-container {
    display: flex;                
    flex-wrap: wrap;              
    gap: 15px;                    
    justify-content: flex-start;  
}

/* Estilo para cada cuadro de evento */
.event-card {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 15px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    height: 150px;
    width: 180px; 
}

/* Estilo para los títulos de cada evento */
.event-card h3 {
    margin-top: 0;
}

/* Estilo para los párrafos dentro de los cuadros */
.event-card p {
    margin: 5px 0;
}


/* Estilos para mensajes de carga y error */
.error-message {
    color: #dc3545;
    font-weight: bold;
    margin-bottom: 15px;
}
    </style>

</head>
<body>
    <?php include "includes/header.php"; ?>
    <main>
        <h1>Lista de Eventos</h1>

        <!-- Barra de búsqueda -->
        <div class="search-container">
            <input type="text" id="searchEvent" placeholder="Buscar por Nombre del Evento" value="<?php echo htmlspecialchars($search_event); ?>">
            <input type="text" id="searchClient" placeholder="Buscar por DNI/RUC del Cliente" value="<?php echo htmlspecialchars($search_client); ?>">
            <input type="date" id="searchDate" placeholder="Buscar por Fecha" value="<?php echo htmlspecialchars($search_date); ?>">
            <a href="nuevo_evento.php" class="new-event-button">
                <img src="img/+evento.png" alt="Nuevo Evento" style="width: 47px; height: auto;">
            </a>
        </div>

        <!-- Espacio para eventos próximos -->
        <section class="upcoming-events">
    <h2>Eventos Próximos</h2>
    <?php if (isset($upcoming_events_result) && $upcoming_events_result->num_rows > 0): ?>
        <div class="upcoming-events-container">
            <?php while ($row = $upcoming_events_result->fetch_assoc()): ?>
                <div class="event-card">
                    <h3><?php echo htmlspecialchars($row['nombre_evento']); ?></h3>
                    <p>Fecha: <?php echo htmlspecialchars(date('d/m/Y', strtotime($row['fecha']))); ?></p>
                    <p>Días faltantes: <?php echo floor((strtotime($row['fecha']) - time()) / (60 * 60 * 24)); ?></p>
                    <a href="detalle_evento.php?evento_id=<?php echo $row['id']; ?>" class="action-button detail" target="_blank">Detalle</a>
                    </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p>No hay eventos próximos.</p>
    <?php endif; ?>
</section>

        <!-- Tabla para mostrar los eventos -->
        <table border="1">
            <thead>
                <tr>
                    <th>Nombre del Evento</th>
                    <th>Fecha</th>
                    <th>Cliente</th>
                    <th>Temática</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="eventosData">
                <?php if (isset($result) && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['nombre_evento']); ?></td>
                            <td><?php echo htmlspecialchars($row['fecha']); ?></td>
                            <td>
                                <a href="clientes.php?highlight_client_id=<?php echo $row['cliente_id']; ?>">
                                    <?php echo htmlspecialchars($row['cliente_nombre']); ?>
                                </a>
                            </td>
                            <td><?php echo htmlspecialchars($row['tematica']); ?></td>
                            <td>
                            <a href="detalle_evento.php?evento_id=<?php echo $row['id']; ?>" class="action-button detail" target="_blank">Detalle</a>
                            <a href="authenticate3.php?redirect=e_edit.php?id=<?php echo $row['id']; ?>" class="action-button edit">Editar</a>
                                <a href="authenticate3.php?redirect=e_delete.php?id=<?php echo $row['id']; ?>" class="action-button delete" onclick="return confirm('¿Estás seguro de que quieres eliminar este evento?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">No se encontraron eventos</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        
    </main>

    <!-- Script para búsqueda en tiempo real -->
    <script>
        $(document).ready(function() {
            function updateTable() {
                var searchEvent = $('#searchEvent').val();
                var searchClient = $('#searchClient').val();
                var searchDate = $('#searchDate').val();

                // Mostrar un mensaje de carga
                $('#eventosData').html('<tr><td colspan="5">Cargando...</td></tr>');

                $.ajax({
                    url: 'index.php',
                    type: 'GET',
                    data: { search_event: searchEvent, search_client: searchClient, search_date: searchDate },
                    success: function(response) {
                        var newContent = $(response).find('#eventosData').html();
                        $('#eventosData').html(newContent);
                    }
                });
            }

            $('#searchEvent, #searchClient, #searchDate').on('input', function() {
                updateTable();
            });
        });
    </script>
</body>
</html>
