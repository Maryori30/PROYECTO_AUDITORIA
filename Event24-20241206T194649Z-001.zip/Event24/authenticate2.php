<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $password = $_POST['password'] ?? '';

    // La contraseña preestablecida (debe ser la misma en el archivo de autenticación y en el archivo de verificación)
    $predefined_password = 'mi/doc'; // Ajusta esta contraseña según tu necesidad

    if ($password === $predefined_password) {
        $_SESSION['authenticated'] = true;
        $redirect = $_GET['redirect'] ?? 'contactos.php';
        header("Location: $redirect");
        exit();
    } else {
        $error = 'Contraseña incorrecta.';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autenticación</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?php include "includes/header.php"; ?>

    <main>
        <h1>Autenticación</h1>
        <?php if (isset($error)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="POST" action="authenticate2.php?redirect=<?php echo urlencode($_GET['redirect'] ?? 'contactos.php'); ?>">
            <label for="password">Contraseña:</label>
            <input type="password" name="password" id="password" required>
            <button type="submit">Ingresar</button>
        </form>
    </main>
</body>
</html>
