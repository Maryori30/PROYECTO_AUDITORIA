<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables para búsqueda
$search = '';
$sql = "SELECT * FROM trabajador";

// Procesar búsqueda si se envía el formulario
if (isset($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']); // Escapar caracteres especiales
    $sql = "SELECT * FROM trabajador WHERE nombres LIKE '%$search%' OR dni LIKE '%$search%'";
}

// Ejecutar la consulta
$result = $conn->query($sql);

// Verificar si la consulta fue exitosa
if ($result === FALSE) {
    die("Error en la consulta: " . $conn->error);
}

// Obtener el ID del nuevo trabajador y el mensaje si están presentes
$new_trabajador_id = isset($_GET['new_trabajador_id']) ? intval($_GET['new_trabajador_id']) : null;
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Trabajadores</title>
    <link rel="stylesheet" href="css/stclientes.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body>
    <?php include "includes/header.php"; ?>
    <main>
        <h1>Lista de Trabajadores</h1>

        <!-- Mostrar mensaje de éxito -->
        <?php if (!empty($message)): ?>
            <div class="success-message"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Barra de búsqueda -->
        <div class="search-container">
            <input type="text" id="searchTerm" placeholder="Buscar por Nombre o DNI/C.E" value="<?php echo htmlspecialchars($search); ?>">
            <a href="nuevo_trabajador.php" class="new-contact-button">
                <img src="img/add-contacto.png" alt="Nuevo Trabajador" style="width: 47px; height: auto;">
            </a>        
        </div>

        <!-- Tabla para mostrar los trabajadores -->
        <table border="1">
            <thead>
                <tr>
                    <th>Nombres</th>
                    <th>Apellidos</th>
                    <th>DNI/C.E</th>
                    <th>Correo</th>
                    <th>Rol</th>
                    <th>Celular</th>
                    <th>Dirección</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="contactosData">
                <?php if (isset($result) && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr <?php echo ($row['id'] == $new_trabajador_id) ? 'class="highlight"' : ''; ?>>
                            <td><?php echo htmlspecialchars($row['nombres']); ?></td>
                            <td><?php echo htmlspecialchars($row['apellidos']); ?></td>
                            <td><?php echo htmlspecialchars($row['dni']); ?></td>
                            <td><?php echo htmlspecialchars($row['correo']); ?></td>
                            <td><?php echo htmlspecialchars($row['rol']); ?></td>
                            <td><?php echo htmlspecialchars($row['celular']); ?></td>
                            <td><?php echo htmlspecialchars($row['direccion']); ?></td>
                            <td>
                            <a href="authenticate.php?redirect=t_edit.php?id=<?php echo $row['id']; ?>" class="action-button edit">Editar</a>
                            <a href="authenticate.php?redirect=t_delete.php?id=<?php echo $row['id']; ?>" class="action-button delete" onclick="return confirm('¿Estás seguro de que quieres eliminar este trabajador?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No se encontraron trabajadores.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>

    <script>
        $(document).ready(function() {
            $('#searchTerm').on('input', function() {
                var searchValue = $(this).val().toLowerCase();
                $('#contactosData tr').each(function() {
                    var rowText = $(this).text().toLowerCase();
                    $(this).toggle(rowText.indexOf(searchValue) !== -1);
                });
            });
        });
    </script>
</body>
</html>
