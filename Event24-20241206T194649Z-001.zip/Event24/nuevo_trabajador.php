<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables y mensajes
$message = '';
$error = '';
$nombres = '';
$apellidos = '';
$dni = '';
$correo = '';
$rol = '';
$celular = '';
$direccion = '';
$cod_ingreso = '';
$contraseña = '';

// Procesar el formulario al enviarlo
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener y escapar datos del formulario
    $nombres = $conn->real_escape_string($_POST['nombres']);
    $apellidos = $conn->real_escape_string($_POST['apellidos']);
    $dni = $conn->real_escape_string($_POST['dni']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $rol = $conn->real_escape_string($_POST['rol']);
    $celular = $conn->real_escape_string($_POST['celular']);
    $direccion = $conn->real_escape_string($_POST['direccion']);
    $cod_ingreso = $conn->real_escape_string($_POST['cod_ingreso']);
    $contraseña = $conn->real_escape_string($_POST['contraseña']);

    // Validar campos obligatorios
    if (empty($nombres) || empty($rol) || empty($celular) || empty($cod_ingreso) || empty($contraseña)) {
        $error = "Todos los campos son obligatorios, excepto el sitio web.";
    } else {
        // Preparar la consulta SQL para insertar el contacto
        $sql = "INSERT INTO trabajador (nombres, apellidos, dni, correo, rol, celular , direccion , cod_ingreso , contraseña)
                VALUES ('$nombres', '$apellidos', '$dni', '$correo', '$rol', '$celular', '$direccion', '$cod_ingreso' , '$contraseña')";

        // Ejecutar la consulta
        if ($conn->query($sql) === TRUE) {
            $last_id = $conn->insert_id; // Obtener el ID del nuevo trabajador
            $message = "Trabajador registrado exitosamente.";
            // Redirigir a trabajador.php con el ID del nuevo trabajador
            header("Location: trabajador.php?new_trabajador_id=$last_id&message=" . urlencode($message));
            exit();
        } else {
            $error = "Error al registrar al trabajador: " . $conn->error;
        }
    }
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Trabajador</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?php include "includes/header.php"; ?>

    <main>
        <h1>Registrar Nuevo Trabajador</h1>

        <!-- Mostrar mensajes -->
        <?php if (!empty($message)): ?>
            <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Formulario de registro de contactos -->
        <form method="POST" action="nuevo_trabajador.php">
            <label for="nombres">Nombres:</label>
            <input type="text" name="nombres" id="nombres" value="<?php echo htmlspecialchars($nombres); ?>" required>

            <label for="apellidos">Apellidos:</label>
            <input type="text" name="apellidos" id="apellidos" value="<?php echo htmlspecialchars($apellidos); ?>" required>

            <label for="dni">DNI/C.E:</label>
            <input type="text" name="dni" id="dni" value="<?php echo htmlspecialchars($dni); ?>" required>

            <label for="correo">Correo:</label>
            <input type="email" name="correo" id="correo" value="<?php echo htmlspecialchars($correo); ?>" required>

            <label for="rol">Rol:</label>
            <input type="text" name="rol" id="rol" value="<?php echo htmlspecialchars($rol); ?>">

            <label for="celular">Celular:</label>
            <input type="text" name="celular" id="celular" value="<?php echo htmlspecialchars($celular); ?>">

            <label for="direccion">Dirección:</label>
            <input type="text" name="direccion" id="direccion" value="<?php echo htmlspecialchars($direccion); ?>" required>

            <label for="cod_ingreso">Código de Ingreso:</label>
            <input type="number" name="cod_ingreso" id="cod_ingreso" value="<?php echo htmlspecialchars($cod_ingreso); ?>" required>

            <label for="contraseña">Contraseña:</label>
            <input type="password" name="contraseña" id="contraseña" value="<?php echo htmlspecialchars($contraseña); ?>" required>

            <button type="submit">Registrar</button>
        </form>
    </main>
</body>
</html>
