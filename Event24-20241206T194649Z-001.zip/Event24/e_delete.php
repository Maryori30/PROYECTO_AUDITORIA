<?php
// e_delete.php

// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables
$id = $_GET['id'] ?? '';
$message = '';
$error = '';

// Iniciar sesión
session_start();

// Verificar autenticación
if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    header("Location: authenticate3.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

// Eliminar los servicios complementarios asociados al evento
if ($id) {
    // Comenzar una transacción
    $conn->begin_transaction();

    try {
        // Eliminar los servicios complementarios asociados
        $sql = "DELETE FROM servicios_complementarios WHERE evento_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();

        // Eliminar el evento
        $sql = "DELETE FROM eventos WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);
        $stmt->execute();

        // Confirmar la transacción
        $conn->commit();

        $message = "Evento y sus servicios complementarios eliminados exitosamente.";
        // Redirigir después de 2 segundos a la lista de eventos
        header("Refresh: 2; url=index.php");
        exit(); // Asegúrate de salir después de redirigir
    } catch (Exception $e) {
        // Revertir la transacción en caso de error
        $conn->rollback();
        $error = "Error: " . $e->getMessage();
    }
} else {
    $error = "ID de evento no proporcionado.";
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Evento</title>
    <link rel="stylesheet" href="css/stclientes.css">
</head>
<body>
    <?php include "includes/header.php"; ?>

    <main>
        <h1>Eliminar Evento</h1>

        <?php if ($message): ?>
            <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <a href="index.php">Volver a la lista de eventos</a>
    </main>
</body>
</html>
