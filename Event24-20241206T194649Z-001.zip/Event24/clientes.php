<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables para búsqueda
$search = '';
$sql = "SELECT * FROM clientes";

// Obtener el ID del cliente asociado y el ID del nuevo cliente si existen
$highlight_client_id = isset($_GET['highlight_client_id']) ? $_GET['highlight_client_id'] : null;
// Procesar búsqueda si se envía el formulario
if (isset($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']); // Escapar caracteres especiales
    $sql = "SELECT * FROM clientes WHERE nombres LIKE '%$search%' OR dni_ruc LIKE '%$search%'";
}

// Ejecutar la consulta
$result = $conn->query($sql);

// Verificar si la consulta fue exitosa
if ($result === FALSE) {
    die("Error en la consulta: " . $conn->error);
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Clientes</title>
    <link rel="stylesheet" href="css/stclientes.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   
</head>
<body>
    <?php include "includes/header.php"; ?>
    <main>
        <h1>Lista de Clientes</h1>

        <!-- Barra de búsqueda -->
        <div class="search-container">
            <input type="text" id="searchTerm" placeholder="Buscar por Nombre o DNI/RUC" value="<?php echo htmlspecialchars($search); ?>">
            <a href="nuevo_cliente.php" class="new-client-button">
                <img src="img/6ty.png" alt="Nuevo Cliente" style="width: 47px; height: auto;">
            </a>
        </div>

        <!-- Tabla para mostrar los clientes -->
        <table border="1">
            <thead>
                <tr>
                    <th>Nombres</th>
                    <th>Apellidos</th>
                    <th>DNI/RUC</th>
                    <th>Correo</th>
                    <th>Edad</th>
                    <th>Celular</th>
                    <th>Dirección</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="clientesData">
                <!-- Resultados -->
                <?php if (isset($result) && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr class="<?php echo ($highlight_client_id === $row['id']) ? 'highlight' : ''; ?>" data-id="<?php echo $row['id']; ?>">                            
                            <td><?php echo htmlspecialchars($row['nombres']); ?></td>
                            <td><?php echo htmlspecialchars($row['apellidos']); ?></td>
                            <td><?php echo htmlspecialchars($row['dni_ruc']); ?></td>
                            <td><?php echo htmlspecialchars($row['correo']); ?></td>
                            <td><?php echo htmlspecialchars($row['edad']); ?></td>
                            <td><?php echo htmlspecialchars($row['celular']); ?></td>
                            <td><?php echo htmlspecialchars($row['direccion']); ?></td>
                            <td>
                                <a href="authenticate.php?redirect=c_edit.php?id=<?php echo $row['id']; ?>" class="action-button edit">Editar</a>
                                <a href="authenticate.php?redirect=c_delete.php?id=<?php echo $row['id']; ?>" class="action-button delete" onclick="return confirm('¿Estás seguro de que quieres eliminar este cliente?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8">No se encontraron resultados</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>

    <!-- Script para búsqueda en tiempo real -->
    <script>
        $(document).ready(function() {
            $('#searchTerm').on('input', function() {
                var searchTerm = $(this).val();

                // Mostrar un mensaje de carga
                $('#clientesData').html('<tr><td colspan="8">Cargando...</td></tr>');

                $.ajax({
                    url: 'clientes.php', // Mismo archivo para manejar AJAX
                    type: 'GET',
                    data: { search: searchTerm },
                    success: function(response) {
                        // Extraer solo el contenido de la tabla de la respuesta
                        var newContent = $(response).find('#clientesData').html();
                        $('#clientesData').html(newContent); // Actualizar los datos en la tabla
                    }
                });
            });

            // Desplazar automáticamente a la fila resaltada
            setTimeout(function() {
                var highlightId = "<?php echo $highlight_client_id; ?>";
                if (highlightId) {
                    var row = $('tr[data-id="' + highlightId + '"]');
                    if (row.length) {
                        $('html, body').animate({
                            scrollTop: row.offset().top
                        }, 1000); // Desplazamiento suave de 1 segundo
                        
                    }
                }
            }, 100); // Esperar a que la tabla se renderice antes de hacer scroll
        

            // Desvanecer el resaltado después de unos segundos
            setTimeout(function() {
                $(".highlight").removeClass("highlight");
            }, 5000); // segundos de resaltado
        }); 
    </script>
</body>
</html>

