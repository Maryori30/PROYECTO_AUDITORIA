<?php
// Incluir la biblioteca TCPDF
require_once('library/tcpdf.php');

// Conexión a la base de datos
$host = "localhost";
$username = "root";
$password = "";
$database = "agenda";
$conn = new mysqli($host, $username, $password, $database);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar la solicitud para generar el PDF
if (isset($_GET['id'])) {
    $evento_id = intval($_GET['id']);

    // Obtener los detalles del evento
    $stmt_evento = $conn->prepare("SELECT * FROM eventos WHERE id = ?");
    $stmt_evento->bind_param("i", $evento_id);
    $stmt_evento->execute();
    $evento = $stmt_evento->get_result()->fetch_assoc();

    if ($evento) {
        // Obtener los servicios complementarios del evento
        $stmt_servicios = $conn->prepare("SELECT * FROM servicios_complementarios WHERE evento_id = ?");
        $stmt_servicios->bind_param("i", $evento_id);
        $stmt_servicios->execute();
        $servicios = $stmt_servicios->get_result();

        // Crear el PDF
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // Configuración del PDF
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('Nombre del Autor');
        $pdf->SetTitle('Nuevo Evento Creado');
        $pdf->SetKeywords('Evento, PDF');

        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);

        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        $pdf->SetFont('helvetica', '', 10);
        $pdf->AddPage();

        // Contenido del PDF
        $html = "<h1>Proforma para Evento</h1>
         <p>---------------------------------------------------------------------------------------------------------------------------------------------------------</p>
         <h3>Decoración</h3>
         <p>Nombre del evento: {$evento['nombre_evento']}</p>
         <p>Fecha: {$evento['fecha']}</p>
         <p>Ubicación: {$evento['ubicacion']}</p>
         <p>Temática: {$evento['tematica']}</p>
         <p>Número de invitados: {$evento['num_invitados']}</p>
         <p>----- Total Evento (S/): " . ($evento['total_evento'] ?? 'N/A') . "</p>
         <p>----- Total Servicios Complementarios (S/): " . ($evento['total_servicios'] ?? 'N/A') . "</p>
         <p>----- Total General (S/): " . ($evento['total_general'] ?? 'N/A') . "</p>
         <p>---------------------------------------------------------------------------------------------------------------------------------------------------------</p>
         <h3>Servicios Complementarios</h3>";

        $hay_servicios = false;

        while ($servicio = $servicios->fetch_assoc()) {
            if (!empty($servicio['detalles']) && !empty($servicio['monto'])) {
                $hay_servicios = true;
                $html .= "<p>Servicio: " . ucfirst($servicio['servicio']) . "</p>
                          <p>Detalles: {$servicio['detalles']}</p>
                          <p>Monto (S/): {$servicio['monto']}</p>";
            }
        }

        if (!$hay_servicios) {
            $html .= "<p>No se han agregado servicios complementarios.</p>";
        }

        $pdf->writeHTML($html, true, false, true, false, '');

        // Descargar el PDF
        $pdf->Output('evento_' . $evento_id . '.pdf', 'I'); // Generar nombre dinámico
    } else {
        echo "No se encontró el evento.";
    }

    $stmt_evento->close();
    $stmt_servicios->close();
} else {
    echo "No se ha proporcionado un ID de evento.";
}

// Cerrar conexión
$conn->close();
?>