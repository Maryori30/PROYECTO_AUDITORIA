<?php
require_once('library/tcpdf.php');

// Conexión a la base de datos
$host = 'localhost';
$user = 'root';
$password = ''; 
$database = 'agenda'; 

$conn = new mysqli($host, $user, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si evento_id está en la solicitud GET
if (!isset($_GET['evento_id']) || empty($_GET['evento_id'])) {
    die("Error: No se proporcionó 'evento_id'.");
}

$evento_id = intval($_GET['evento_id']);

// Preparar y ejecutar la consulta SQL para obtener los detalles del evento
$sql = "SELECT * FROM eventos WHERE id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error al preparar la consulta: " . $conn->error);
}

$stmt->bind_param("i", $evento_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $evento = $result->fetch_assoc();
} else {
    die("<p>No se encontró el evento con ID " . htmlspecialchars($evento_id) . ".</p>");
}

// Obtener servicios asociados
$sql = "SELECT * FROM servicios_complementarios WHERE evento_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error al preparar la consulta: " . $conn->error);
}

$stmt->bind_param("i", $evento_id);
$stmt->execute();
$result_servicios = $stmt->get_result();

// Obtener archivos asociados
$sql = "SELECT * FROM archivos_eventos WHERE evento_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error al preparar la consulta: " . $conn->error);
}

$stmt->bind_param("i", $evento_id);
$stmt->execute();
$result_archivos = $stmt->get_result();

$stmt->close();
$conn->close();

// Generar PDF si se solicita
if (isset($_POST['generar_pdf'])) {
    // Crear nuevo objeto TCPDF
    $pdf = new TCPDF();
    $pdf->AddPage();
    
    // Establecer título y contenido
    $pdf->SetTitle('Detalles del Evento');
    
    // Agregar contenido del evento
    $html = "<h1>Detalles del Evento</h1>";
    $html .= "<p>ID: " . htmlspecialchars($evento['id']) . "</p>";
    $html .= "<p>Nombre: " . htmlspecialchars($evento['nombre_evento']) . "</p>";
    $html .= "<p>Fecha: " . htmlspecialchars($evento['fecha']) . "</p>";
    $html .= "<p>Ubicación: " . htmlspecialchars($evento['ubicacion']) . "</p>";
    $html .= "<p>Temática: " . htmlspecialchars($evento['tematica']) . "</p>";
    $html .= "<p>Número de Invitados: " . htmlspecialchars($evento['num_invitados']) . "</p>";
    $html .= "<p>Cliente ID: " . htmlspecialchars($evento['cliente_id']) . "</p>";
    $html .= "<p>Total Evento: " . htmlspecialchars($evento['total_evento']) . "</p>";
    $html .= "<p>Total Servicios: " . htmlspecialchars($evento['total_servicios']) . "</p>";
    $html .= "<p>Total General: " . htmlspecialchars($evento['total_general']) . "</p>";
    
    // Agregar servicios
    $html .= "<h2>Servicios Asociados</h2>";
    while ($servicio = $result_servicios->fetch_assoc()) {
        $html .= "<p>Servicio: " . htmlspecialchars($servicio['servicio']) . "<br>";
        $html .= "Detalles: " . htmlspecialchars($servicio['detalles']) . "<br>";
        $html .= "Precio: " . htmlspecialchars($servicio['monto']) . "<br>";
        $html .= "Contacto ID: " . htmlspecialchars($servicio['contacto_id']) . "</p>";
    }
    
    // Agregar archivos
    $html .= "<h2>Archivos Asociados</h2>";
    while ($archivo = $result_archivos->fetch_assoc()) {
        $html .= "<p>Nombre del Archivo: " . htmlspecialchars($archivo['nombre_archivo']) . "<br>";
        $html .= "Tipo de Archivo: " . htmlspecialchars($archivo['tipo_archivo']) . "<br>";
        $html .= "Ruta del Archivo: " . htmlspecialchars($archivo['ruta_archivo']) . "<br>";
        $html .= "Fecha de Subida: " . htmlspecialchars($archivo['fecha_subida']) . "</p>";
    }
    
    $pdf->writeHTML($html);
    $pdf->Output('detalles_evento.pdf', 'D');
    exit();
}
?>

<!-- HTML para mostrar los detalles del evento y el formulario -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalles del Evento</title>
</head>
<body>
    <h1>Detalles del Evento</h1>
    <p>ID: <?php echo htmlspecialchars($evento['id']); ?></p>
    <p>Nombre: <?php echo htmlspecialchars($evento['nombre_evento']); ?></p>
    <p>Fecha: <?php echo htmlspecialchars($evento['fecha']); ?></p>
    <p>Ubicación: <?php echo htmlspecialchars($evento['ubicacion']); ?></p>
    <p>Temática: <?php echo htmlspecialchars($evento['tematica']); ?></p>
    <p>Número de Invitados: <?php echo htmlspecialchars($evento['num_invitados']); ?></p>
    <p>Cliente ID: <?php echo htmlspecialchars($evento['cliente_id']); ?></p>
    <p>Total Evento: <?php echo htmlspecialchars($evento['total_evento']); ?></p>
    <p>Total Servicios: <?php echo htmlspecialchars($evento['total_servicios']); ?></p>
    <p>Total General: <?php echo htmlspecialchars($evento['total_general']); ?></p>

    <h2>Servicios Asociados</h2>
    <?php while ($servicio = $result_servicios->fetch_assoc()) { ?>
        <p>Servicio: <?php echo htmlspecialchars($servicio['servicio']); ?><br>
        Detalles: <?php echo htmlspecialchars($servicio['detalles']); ?><br>
        Precio: <?php echo htmlspecialchars($servicio['monto']); ?><br>
        Contacto ID: <?php echo htmlspecialchars($servicio['contacto_id']); ?></p>
    <?php } ?>

    <h2>Archivos Asociados</h2>
    <?php while ($archivo = $result_archivos->fetch_assoc()) { ?>
        <p>Nombre del Archivo: <?php echo htmlspecialchars($archivo['nombre_archivo']); ?><br>
        Tipo de Archivo: <?php echo htmlspecialchars($archivo['tipo_archivo']); ?><br>
        Ruta del Archivo: <?php echo htmlspecialchars($archivo['ruta_archivo']); ?><br>
        Fecha de Subida: <?php echo htmlspecialchars($archivo['fecha_subida']); ?></p>
    <?php } ?>

    <!-- Formulario para generar PDF -->
    <form action="" method="post">
        <input type="hidden" name="evento_id" value="<?php echo htmlspecialchars($evento_id); ?>">
        <button type="submit" name="generar_pdf">Generar PDF</button>
    </form>
</body>
</html>
