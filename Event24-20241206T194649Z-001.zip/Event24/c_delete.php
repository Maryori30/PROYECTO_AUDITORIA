<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
// Inicializar variables
$id = $_GET['id'] ?? '';
$message = '';
$error = '';

// Iniciar sesión
session_start();

// Verificar autenticación
if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    header("Location: authenticate.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

// Eliminar el cliente
if ($id) {
    $sql = "DELETE FROM clientes WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        $message = "Cliente eliminado exitosamente.";
        header("Refresh: 2; url=clientes.php"); // Redirigir después de 2 segundos
    } else {
        $error = "Error: " . $conn->error;
    }
} else {
    die("ID de cliente no proporcionado.");
}

// Cerrar la conexión
$conn->close();


// Finalizar sesión
session_unset(); // Destruir todas las variables de sesión
session_destroy(); // Destruir la sesión
header("Location: clientes.php"); // Redirigir a la lista de clientes
exit();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Cliente</title>
    <link rel="stylesheet" href="css/stclientes.css">
</head>
<body>
    <?php include "includes/header.php"; ?>

    <main>
        <h1>Eliminar Cliente</h1>

        <?php if ($message): ?>
            <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <a href="clientes.php">Volver a la lista de clientes</a>
    </main>
</body>
</html>

