<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Evento</title>
    <?php include "includes/scripts.php"; ?>
</head>
<body>
<header>
    <div class="header">
    <nav>
            <img src="img/logo.png" alt="Logo de la Empresa" class="logo">
            <ul>
                <li><a href="./index.php">Agenda</a></li>
                <li><a href="./nuevo_evento.php">Nuevo evento</a></li>
                <li><a href="./clientes.php">Clientes</a></li>
                <li><a href="./nuevo_cliente.php">Nuevo Cliente</a></li>
                <li><a href="./contactos.php">Contactos</a></li>
                <li><a href="./trabajador.php">Trabajador</a></li>
                <li><a href="https://toque-azul.weeblysite.com/ideas-1" target="_blank">Catálogo</a></li>
            </ul>
    </div>
</header>
</body>
</html>