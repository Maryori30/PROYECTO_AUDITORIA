<?php
// Conexión a la base de datos
$host = "localhost";
$username = "root";
$password = "";
$database = "agenda";
$conn = new mysqli($host, $username, $password, $database);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar el formulario al hacer clic en "Guardar y generar PDF"
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recibir los datos del evento
    $nombre_evento = $_POST['nombre_evento'];
    $fecha = $_POST['fecha'];
    $ubicacion = $_POST['ubicacion'];
    $tematica = $_POST['tematica'];
    $num_invitados = $_POST['num_invitados'];
    $cliente_id = $_POST['cliente_id'];
    $total_evento = $_POST['total_evento'];
    $total_servicios = isset($_POST['total_servicios']) ? $_POST['total_servicios'] : 0; // Asegúrate de que tenga un valor por defecto
    $total_general = $_POST['total_general'];

    // Insertar evento en la base de datos
$sql_evento = "INSERT INTO eventos (nombre_evento, fecha, ubicacion, tematica, num_invitados, cliente_id, total_evento, total_servicios, total_general)
VALUES ('$nombre_evento', '$fecha', '$ubicacion', '$tematica', $num_invitados, $cliente_id, $total_evento, $total_servicios, $total_general)";

    if ($conn->query($sql_evento) === TRUE) {
        $evento_id = $conn->insert_id; // Obtener el ID del evento recién insertado

        // Insertar servicios complementarios si hay
        if (isset($_POST['servicios'])) {
            foreach ($_POST['servicios'] as $servicio => $detalles) {
                if (isset($detalles['detalle']) && isset($detalles['empresa']) && isset($detalles['monto'])) {
                    $contacto_id = $detalles['empresa'];
                    $monto = $detalles['monto'];
                    $detalle_servicio = $detalles['detalle'];

                    // Preparar la consulta para insertar los servicios
                    $stmt_servicio = $conn->prepare("INSERT INTO servicios_complementarios (evento_id, servicio, detalles, contacto_id, monto) VALUES (?, ?, ?, ?, ?)");
                    $stmt_servicio->bind_param("issii", $evento_id, $servicio, $detalle_servicio, $contacto_id, $monto);
                    
                    if (!$stmt_servicio->execute()) {
                        echo "Error al insertar servicio: " . $stmt_servicio->error;
                    }
                }
            }
        }

        // Redirigir para generar el PDF
        header('Location: generar_pdf.php?id=' . $evento_id);
        exit;
        // echo "Evento guardado correctamente.";

    } else {
        echo "Error al crear el evento: " . $stmt_evento->error;
    }
}

// Cargar clientes registrados para mostrar en el <select>
$clientes = $conn->query("SELECT id, nombres, apellidos, dni_ruc FROM clientes");

// Cargar empresas de contactos registrados para los servicios complementarios
$empresas = $conn->query("SELECT id, nombre_empresa FROM contactos");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Nuevo Evento</title>
    <style>
        .fond {
            padding: 10px;
            width: 800px;
            margin: 50px auto;
            background-color: #fff;
            border-radius: 10px;
        }
        form {
            margin-top: 30px;
            margin-bottom: 50px;
            background-color: #f4f4f4;
            padding: 50px 80px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }
        input, select, button {
            width: 100%;
            margin: 10px auto;
            padding: 10px;
        }
        #servicios_complementarios {
            display: none;
        }
        .detalle-servicio {
            display: none;
        }
    </style>
</head>
<body>
<?php include "includes/header.php"; ?>
<div class="fond">
<h1>Nuevo Evento - Proforma</h1>
<!-- Formulario HTML -->
<form id="formulario" method="POST" action="nuevo_evento.php" target="_blank">
    <!-- Sección 1: Evento -->
    <label>Nombre del evento:</label>
    <input type="text" name="nombre_evento" required><br>

    <label>Fecha y hora:</label>
    <input type="datetime-local" name="fecha" required><br>

    <label>Ubicación:</label>
    <input type="text" name="ubicacion" required><br>

    <label>Temática:</label>
    <input type="text" name="tematica"><br>

    <label>Número de invitados:</label>
    <input type="number" name="num_invitados" required><br>

    <label>Cliente (DNI/RUC):</label>
    <select name="cliente_id" required>
        <?php while ($cliente = $clientes->fetch_assoc()) : ?>
            <option value="<?= $cliente['id'] ?>"><?= $cliente['nombres'] . ' ' . $cliente['apellidos'] . ' (' . $cliente['dni_ruc'] . ')' ?></option>
        <?php endwhile; ?>
    </select><br>

    <label>Total Evento (S/):</label>
    <input type="number" name="total_evento" id="total_evento" required><br>

    <!-- Botón para mostrar la sección de servicios complementarios -->
    <button type="button" id="agregar_servicios">+ Servicios Complementarios</button>

    <!-- Sección 2: Servicios Complementarios -->
    <div id="servicios_complementarios">
        <h3>Servicios Complementarios</h3>
<br>
        <!-- Bocaditos -->
         <p>------------------------------------------------------</p>
        <label>Bocaditos:</label>
        <input type="checkbox" id="bocaditos_check" name="servicios[bocaditos]"><br>
        <div id="bocaditos_detalles" class="detalle-servicio">
            <label>Detalles:</label>
            <input type="text" name="servicios[bocaditos][detalle]"><br>
            <label>Empresa:</label>
            <select name="servicios[bocaditos][empresa]">
                <?php $empresas->data_seek(0); // Resetear el puntero del conjunto de resultados ?>
                <?php while ($empresa = $empresas->fetch_assoc()) : ?>
                    <option value="<?= $empresa['id'] ?>"><?= $empresa['nombre_empresa'] ?></option>
                <?php endwhile; ?>
            </select><br>
            <label>Monto (S/):</label>
            <input type="number" name="servicios[bocaditos][monto]" class="monto-servicio"><br>
        </div>
<br>
        <!-- Luces -->
        <p>------------------------------------------------------</p>
        <label>Luces:</label>
        <input type="checkbox" id="luces_check" name="servicios[luces]"><br>
        <div id="luces_detalles" class="detalle-servicio">
            <label>Detalles:</label>
            <input type="text" name="servicios[luces][detalle]"><br>
            <label>Empresa:</label>
            <select name="servicios[luces][empresa]">
                <?php $empresas->data_seek(0); // Resetear el puntero del conjunto de resultados ?>
                <?php while ($empresa = $empresas->fetch_assoc()) : ?>
                    <option value="<?= $empresa['id'] ?>"><?= $empresa['nombre_empresa'] ?></option>
                <?php endwhile; ?>
            </select><br>
            <label>Monto (S/):</label>
            <input type="number" name="servicios[luces][monto]" class="monto-servicio"><br>
        </div>
<br>
        <!-- Animación -->
        <p>------------------------------------------------------</p>
        <label>Animación:</label>
        <input type="checkbox" id="animacion_check" name="servicios[animacion]"><br>
        <div id="animacion_detalles" class="detalle-servicio">
            <label>Detalles:</label>
            <input type="text" name="servicios[animacion][detalle]"><br>
            <label>Empresa:</label>
            <select name="servicios[animacion][empresa]">
                <?php $empresas->data_seek(0); // Resetear el puntero del conjunto de resultados ?>
                <?php while ($empresa = $empresas->fetch_assoc()) : ?>
                    <option value="<?= $empresa['id'] ?>"><?= $empresa['nombre_empresa'] ?></option>
                <?php endwhile; ?>
            </select><br>
            <label>Monto (S/):</label>
            <input type="number" name="servicios[animacion][monto]" class="monto-servicio"><br>
        </div>
<br><p>------------------------------------------------------</p>

    <label>Total Servicios Complementarios (S/):</label>
    <input type="number" name="total_servicios" id="total_servicios" readonly><br>
    </div>
    <br><br>
    <!-- Total General -->
    <label>Total General (S/):</label>
    <input type="number" name="total_general" id="total_general" readonly><br>

    <button type="submit" name="submit">Guardar y generar PDF</button>
</form>
</div>

<script>
    // Mostrar/ocultar sección de servicios complementarios
    document.getElementById('agregar_servicios').addEventListener('click', function() {
        const servicios = document.getElementById('servicios_complementarios');
        if (servicios.style.display === 'none' || servicios.style.display === '') {
            servicios.style.display = 'block';
        } else {
            servicios.style.display = 'none';
        }
    });

    // Mostrar/ocultar detalles de cada servicio complementario
    function toggleServicioDetalles(servicioId) {
        const check = document.getElementById(servicioId + '_check');
        const detalles = document.getElementById(servicioId + '_detalles');
        if (check.checked) {
            detalles.style.display = 'block';
        } else {
            detalles.style.display = 'none';
            detalles.querySelector('input[name*="[detalle]"]').value = '';
            detalles.querySelector('select[name*="[empresa]"]').selectedIndex = 0;
            detalles.querySelector('input[name*="[monto]"]').value = '';
        }
    }

    document.getElementById('bocaditos_check').addEventListener('change', function() {
        toggleServicioDetalles('bocaditos');
    });
    document.getElementById('luces_check').addEventListener('change', function() {
        toggleServicioDetalles('luces');
    });
    document.getElementById('animacion_check').addEventListener('change', function() {
        toggleServicioDetalles('animacion');
    });

    // Recalcular total de servicios y total general
    const montoServicios = document.querySelectorAll('.monto-servicio');
    const totalServicios = document.getElementById('total_servicios');
    const totalEvento = document.getElementById('total_evento');
    const totalGeneral = document.getElementById('total_general');

    montoServicios.forEach(monto => {
        monto.addEventListener('input', calcularTotales);
    });

    totalEvento.addEventListener('input', calcularTotales);

    function calcularTotales() {
        let sumServicios = 0;
        montoServicios.forEach(monto => {
            if (monto.value) {
                sumServicios += parseFloat(monto.value);
            }
        });
        totalServicios.value = sumServicios;

        totalGeneral.value = parseFloat(totalEvento.value) + parseFloat(totalServicios.value);
    }
    // Vaciar los campos del formulario después del envío
    document.getElementById('formulario').addEventListener('submit', function(event) {
            // Esperar un momento después del envío para vaciar los campos
            setTimeout(function() {
                document.getElementById('formulario').reset();
            }, 100);
        });
</script>
</body>
</html>

<?php
// Cerrar conexión
$conn->close();
?>