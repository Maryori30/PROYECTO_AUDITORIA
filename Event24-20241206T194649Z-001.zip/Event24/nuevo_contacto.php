<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables y mensajes
$message = '';
$error = '';
$nombre_empresa = '';
$rubro = '';
$telefono = '';
$correo = '';
$direccion = '';
$web = '';

// Procesar el formulario al enviarlo
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener y escapar datos del formulario
    $nombre_empresa = $conn->real_escape_string($_POST['nombre_empresa']);
    $rubro = $conn->real_escape_string($_POST['rubro']);
    $telefono = $conn->real_escape_string($_POST['telefono']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $direccion = $conn->real_escape_string($_POST['direccion']);
    $web = $conn->real_escape_string($_POST['web']);

    // Validar campos obligatorios
    if (empty($nombre_empresa) || empty($rubro) || empty($telefono) || empty($correo)) {
        $error = "Todos los campos son obligatorios, excepto el sitio web.";
    } else {
        // Preparar la consulta SQL para insertar el contacto
        $sql = "INSERT INTO contactos (nombre_empresa, rubro, telefono, correo, direccion, web)
                VALUES ('$nombre_empresa', '$rubro', '$telefono', '$correo', '$direccion', '$web')";

        // Ejecutar la consulta
        if ($conn->query($sql) === TRUE) {
            $last_id = $conn->insert_id; // Obtener el ID del nuevo contacto
            $message = "Contacto registrado exitosamente.";
            // Redirigir a contactos.php con el ID del nuevo contacto
            header("Location: contactos.php?new_contact_id=$last_id&message=" . urlencode($message));
            exit();
        } else {
            $error = "Error al registrar el contacto: " . $conn->error;
        }
    }
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Contacto</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?php include "includes/header.php"; ?>

    <main>
        <h1>Registrar Nuevo Contacto</h1>

        <!-- Mostrar mensajes -->
        <?php if (!empty($message)): ?>
            <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Formulario de registro de contactos -->
        <form method="POST" action="nuevo_contacto.php">
            <label for="nombre_empresa">Nombre de Empresa:</label>
            <input type="text" name="nombre_empresa" id="nombre_empresa" value="<?php echo htmlspecialchars($nombre_empresa); ?>" required>

            <label for="rubro">Rubro:</label>
            <input type="text" name="rubro" id="rubro" value="<?php echo htmlspecialchars($rubro); ?>" required>

            <label for="telefono">Teléfono:</label>
            <input type="text" name="telefono" id="telefono" value="<?php echo htmlspecialchars($telefono); ?>" required>

            <label for="correo">Correo:</label>
            <input type="email" name="correo" id="correo" value="<?php echo htmlspecialchars($correo); ?>" required>

            <label for="direccion">Dirección:</label>
            <input type="text" name="direccion" id="direccion" value="<?php echo htmlspecialchars($direccion); ?>">

            <label for="web">Sitio Web:</label>
            <input type="url" name="web" id="web" value="<?php echo htmlspecialchars($web); ?>">

            <button type="submit">Registrar Contacto</button>
        </form>
    </main>
</body>
</html>
