<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables
$id = $_GET['id'] ?? '';
$message = '';
$error = '';

// Iniciar sesión
session_start();

// Verificar autenticación
if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    header("Location: authenticate0.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

// Obtener los datos del trabajador
if ($id) {
    $sql = "SELECT * FROM trabajador WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $trabajador = $result->fetch_assoc();

    if (!$trabajador) {
        die("Trabajador no encontrado.");
    }
} else {
    die("ID de trabajador no proporcionado.");
}

// Procesar el formulario de edición
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombres = $conn->real_escape_string($_POST['nombres']);
    $apellidos = $conn->real_escape_string($_POST['apellidos']);
    $dni = $conn->real_escape_string($_POST['dni']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $rol = $conn->real_escape_string($_POST['rol']);
    $celular = $conn->real_escape_string($_POST['celular']);
    $direccion = $conn->real_escape_string($_POST['direccion']);
    $cod_ingreso = $conn->real_escape_string($_POST['cod_ingreso']);
    $contraseña = $conn->real_escape_string($_POST['contraseña']);

    $sql = "UPDATE trabajador SET nombres = ?, apellidos = ?, dni = ?, correo = ?, rol = ?, celular = ?, direccion = ? , cod_ingreso = ?, contraseña = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssssssssi', $nombres, $apellidos, $dni, $correo, $rol, $celular, $direccion, $cod_ingreso , $contraseña, $id);

    if ($stmt->execute()) {
        $message = "Trabajador actualizado exitosamente.";
        header("Refresh: 2; url=trabajador.php"); // Redirigir después de 2 segundos
    } else {
        $error = "Error: " . $conn->error;
    }
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Trabajador</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<?php include "includes/header.php"; ?>

    <main>
        <h1>Editar Trabajador</h1>

        <?php if ($message): ?>
            <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Formulario de edición de trabajador -->
        <form method="POST" action="t_edit.php?id=<?php echo $id; ?>">
            <label for="nombres">Nombres:</label>
            <input type="text" name="nombres" id="nombres" value="<?php echo htmlspecialchars($trabajador['nombres']); ?>" required>

            <label for="apellidos">Apellidos:</label>
            <input type="text" name="apellidos" id="apellidos" value="<?php echo htmlspecialchars($trabajador['apellidos']); ?>" required>

            <label for="dni">DNI/C.E:</label>
            <input type="text" name="dni" id="dni" value="<?php echo htmlspecialchars($trabajador['dni']); ?>" required>

            <label for="correo">Correo:</label>
            <input type="email" name="correo" id="correo" value="<?php echo htmlspecialchars($trabajador['correo']); ?>" required>

            <label for="rol">Edad:</label>
            <input type="text" name="rol" id="rol" value="<?php echo htmlspecialchars($trabajador['rol']); ?>" required>

            <label for="celular">Celular:</label>
            <input type="text" name="celular" id="celular" value="<?php echo htmlspecialchars($trabajador['celular']); ?>" required>

            <label for="direccion">Dirección:</label>
            <input type="text" name="direccion" id="direccion" value="<?php echo htmlspecialchars($trabajador['direccion']); ?>" required>
            
            <label for="cod_ingreso">Código de Ingreso:</label>
            <input type="number" name="cod_ingreso" id="cod_ingreso" value="<?php echo htmlspecialchars($trabajador['cod_ingreso']); ?>" required>
            
            <label for="contraseña">Contraseña:</label>
            <input type="password" name="contraseña" id="contraseña" value="<?php echo htmlspecialchars($trabajador['contraseña']); ?>" required>

            <button type="submit">Actualizar Cliente</button>
        </form>
    </main>
</body>
</html>
