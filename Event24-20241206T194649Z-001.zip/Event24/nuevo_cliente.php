<?php 
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables y mensajes
$message = '';
$error = '';
$nombres = '';
$apellidos = '';
$dni_ruc = '';
$correo = '';
$edad = '';
$celular = '';
$direccion = '';

// Procesar el formulario al enviarlo
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener y escapar datos del formulario
    $nombres = $conn->real_escape_string($_POST['nombres']);
    $apellidos = $conn->real_escape_string($_POST['apellidos']);
    $dni_ruc = $conn->real_escape_string($_POST['dni_ruc']);
    $correo = $conn->real_escape_string($_POST['correo']);
    $edad = $conn->real_escape_string($_POST['edad']);
    $celular = $conn->real_escape_string($_POST['celular']);
    $direccion = $conn->real_escape_string($_POST['direccion']);

    // Preparar la consulta SQL
    $sql = "INSERT INTO clientes (nombres, apellidos, dni_ruc, correo, edad, celular, direccion)
            VALUES ('$nombres', '$apellidos', '$dni_ruc', '$correo', '$edad', '$celular', '$direccion')";

    // Ejecutar la consulta
    if ($conn->query($sql) === TRUE) {
        // Obtener el ID del cliente recién insertado
        $new_cliente_id = $conn->insert_id;
        // Redirigir a clientes.php con el parámetro del nuevo cliente
        header("Location: clientes.php?new_cliente_id=" . $new_cliente_id);
        exit(); // Asegurar que se detiene el script después de redirigir
    } else {
        $error = "Error: " . $conn->error;
    }
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Cliente</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<?php include "includes/header.php"; ?>

    <main>
        <h1>Registrar Nuevo Cliente</h1>

        <?php if ($message): ?>
            <div class="success-message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- Formulario de registro de clientes -->
        <form method="POST" action="nuevo_cliente.php">
            <label for="nombres">Nombres:</label>
            <input type="text" name="nombres" id="nombres" value="<?php echo htmlspecialchars($nombres); ?>" required>

            <label for="apellidos">Apellidos:</label>
            <input type="text" name="apellidos" id="apellidos" value="<?php echo htmlspecialchars($apellidos); ?>" required>

            <label for="dni_ruc">DNI/RUC:</label>
            <input type="text" name="dni_ruc" id="dni_ruc" value="<?php echo htmlspecialchars($dni_ruc); ?>" required>

            <label for="correo">Correo:</label>
            <input type="email" name="correo" id="correo" value="<?php echo htmlspecialchars($correo); ?>" required>

            <label for="edad">Edad:</label>
            <input type="number" name="edad" id="edad" value="<?php echo htmlspecialchars($edad); ?>" required>

            <label for="celular">Celular:</label>
            <input type="text" name="celular" id="celular" value="<?php echo htmlspecialchars($celular); ?>" required>

            <label for="direccion">Dirección:</label>
            <input type="text" name="direccion" id="direccion" value="<?php echo htmlspecialchars($direccion); ?>" required>

            <button type="submit">Registrar Cliente</button>
        </form>
    </main>
</body>
</html>
