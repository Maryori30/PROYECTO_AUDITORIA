<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si se ha proporcionado un ID de evento
if (isset($_GET['id']) || isset($_POST['id'])) {
    $event_id = isset($_GET['id']) ? intval($_GET['id']) : intval($_POST['id']);

    // Si no se proporciona un ID, redirigir o mostrar un error
    if ($event_id <= 0) {
        die("Evento no válido.");
    }

    // Obtener la información del evento
    $event_query = "SELECT * FROM eventos WHERE id = $event_id";
    $event_result = $conn->query($event_query);

    if ($event_result->num_rows == 0) {
        die("Evento no encontrado.");
    }

    $event = $event_result->fetch_assoc();

    // Obtener los servicios complementarios del evento
    $services_query = "SELECT s.*, c.nombre_empresa FROM servicios_complementarios s
                    LEFT JOIN contactos c ON s.contacto_id = c.id
                    WHERE s.evento_id = $event_id";
    $services_result = $conn->query($services_query);

    if (!$services_result) {
        die("Error en la consulta de servicios: " . $conn->error);
    }

    // Obtener la lista de contactos para el dropdown en servicios
    $contacts_query = "SELECT id, nombre_empresa FROM contactos";
    $contacts_result = $conn->query($contacts_query);

    
        

    // Procesar el formulario de edición
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nombre_evento = $conn->real_escape_string($_POST['nombre_evento']);
        $fecha = $conn->real_escape_string($_POST['fecha']);
        $ubicacion = $conn->real_escape_string($_POST['ubicacion']);
        $tematica = $conn->real_escape_string($_POST['tematica']);
        $num_invitados = (int)$_POST['num_invitados'];
        $cliente_id = (int)$_POST['cliente_id'];
        $total_evento = (float)$_POST['total_evento'];
        $total_general = (float)$_POST['total_general'];

        // Actualizar la información del evento
        $update_event_query = "UPDATE eventos SET 
            nombre_evento = '$nombre_evento',
            fecha = '$fecha',
            ubicacion = '$ubicacion',
            tematica = '$tematica',
            num_invitados = $num_invitados,
            cliente_id = $cliente_id,
            total_evento = $total_evento,
            total_general = $total_general
            WHERE id = $event_id";

        if ($conn->query($update_event_query) === TRUE) {
            // Actualizar servicios complementarios
            foreach ($_POST['servicios'] as $key => $service_data) {
                if (isset($service_data['detalles']) && isset($service_data['contacto_id']) && isset($service_data['monto'])) {
                    $detalle = $conn->real_escape_string($service_data['detalles']);
                    $empresa_id = (int)$service_data['contacto_id'];
                    $monto = (float)$service_data['monto'];
                    $servicio = $conn->real_escape_string($service_data['servicio']);

                    // Verificar si es un nuevo servicio o uno existente
                    if ($key === 'nuevo') {
                        // Insertar nuevo servicio
                        $insert_service_query = "INSERT INTO servicios_complementarios (evento_id, servicio, detalles, contacto_id, monto) VALUES 
                            ($event_id, '$servicio', '$detalle', $empresa_id, $monto)";
                        $conn->query($insert_service_query);
                    } else {
                        // Actualizar servicio existente
                        $update_service_query = "UPDATE servicios_complementarios SET 
                            detalles = '$detalle',
                            contacto_id = $empresa_id,
                            monto = $monto
                            WHERE evento_id = $event_id AND id = $key";
                        $conn->query($update_service_query);
                    }
                }
            }


            // Eliminar servicios que no están en el formulario
            $existing_services = array_keys($_POST['servicios']);
            $delete_services_query = "DELETE FROM servicios_complementarios WHERE evento_id = $event_id AND id NOT IN (" . implode(',', $existing_services) . ")";
            $conn->query($delete_services_query);

            

            // Redirigir a la lista de eventos o mostrar un mensaje de éxito
            header("Location: index.php");
            exit();
        } else {
            die("Error al actualizar el evento: " . $conn->error);
        }
    }

} else {
    die("ID de evento no proporcionado.");
}

// Cargar clientes registrados para mostrar en el <select>
$clientes = $conn->query("SELECT id, nombres, apellidos, dni_ruc FROM clientes");

// Cargar empresas de contactos registrados para los servicios complementarios
$empresas = $conn->query("SELECT id, nombre_empresa FROM contactos");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Evento</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-mask-plugin@1.14.16/dist/jquery.mask.min.js"></script>
    <style>
        .service-item { margin-bottom: 10px; }
        .remove-service { margin-left: 10px; }
        .remove-service{
            color:white;
            background-color:red;
            white: 60px;
            margin: auto;
        }
    </style>
</head>
<body>
    <?php include "includes/header.php"; ?>
    <main>
        <h1>Editar Evento</h1>
        <form action="e_edit.php?id=<?php echo $event_id; ?>" method="post" enctype="multipart/form-data">
            <!-- Campos del formulario -->
            <label for="nombre_evento">Nombre del Evento:</label>
            <input type="text" id="nombre_evento" name="nombre_evento" value="<?php echo htmlspecialchars($event['nombre_evento']); ?>" required>

            <label for="fecha">Fecha:</label>
            <input type="datetime-local" id="fecha" name="fecha" value="<?php echo htmlspecialchars($event['fecha']); ?>" required>

            <label for="ubicacion">Ubicación</label>
            <input type="text" id="ubicacion" name="ubicacion" value="<?php echo htmlspecialchars($event['ubicacion']); ?>" required>

            <label for="tematica">Temática</label>
            <input type="text" id="tematica" name="tematica" value="<?php echo htmlspecialchars($event['tematica']); ?>" required>

            <label for="num_invitados">Numero de Invitados</label>
            <input type="number" id="num_invitados" name="num_invitados" value="<?php echo htmlspecialchars($event['num_invitados']); ?>" required>

            <label for="cliente_id">Cliente (DNI/RUC):</label>
        <select name="cliente_id" required>
        <?php while ($cliente = $clientes->fetch_assoc()) : ?>
            <option value="<?= $cliente['id'] ?>" <?= $cliente['id'] == $event['cliente_id'] ? 'selected' : '' ?>>
                <?= $cliente['nombres'] . ' ' . $cliente['apellidos'] . ' (' . $cliente['dni_ruc'] . ')' ?>
            </option>
        <?php endwhile; ?>
        </select><br>

        <label for="total_evento">Total Evento (S/):</label>
        <input type="number" id="total_evento" name="total_evento" value="<?php echo htmlspecialchars($event['total_evento']); ?>" required>
            
            <!-- Muestra correcta de servicios complementarios -->
            <h2>Servicios Complementarios</h2>
            <div id="services-container">
                <?php while ($service = $services_result->fetch_assoc()) { ?>
                    <div class="service-item">
                        <label>Tipo de Servicio:</label>
                        <input type="text" name="servicios[<?php echo $service['id']; ?>][servicio]" value="<?php echo htmlspecialchars($service['servicio']); ?>" required>
                        
                        <label>Detalles:</label>
                        <input type="text" name="servicios[<?php echo $service['id']; ?>][detalles]" value="<?php echo htmlspecialchars($service['detalles']); ?>" required>

                        <label>Precio:</label>
                        <input type="number"  name="servicios[<?php echo $service['id']; ?>][monto]" value="<?php echo htmlspecialchars($service['monto']); ?>" class="monto-servicio" required>                        <label>Empresa/Contacto:</label>
                        
                        <select name="servicios[<?php echo $service['id']; ?>][contacto_id]" required>
                            <option value="">Seleccione un contacto</option>
                            <?php
                            // Mover el puntero de contactos al inicio
                            $contacts_result->data_seek(0);
                            while ($contact = $contacts_result->fetch_assoc()) {
                                $selected = $contact['id'] == $service['contacto_id'] ? 'selected' : '';
                                echo "<option value='{$contact['id']}' $selected>{$contact['nombre_empresa']}</option>";
                            } ?>
                        </select> <br><br>

                        <button type="button" class="remove-service">Eliminar</button>
                    </div>
                <?php } ?>
            </div>
            <br>
            <button type="button" id="add-service">Agregar Servicio</button>
            <br><br>
            <label for="total_general">Total General (S/):</label>
            <input type="text" id="total_general" name="total_general" value="<?php echo htmlspecialchars($event['total_general']); ?>" required readonly>            <!-- Sección Archivos Subidos -->
            
            <!-- <label>Archivos Subidos:</label> -->
    

    <!-- Subir Archivos -->
    <form action="subir_archivos.php" method="POST" enctype="multipart/form-data">
    <label>Subir Archivos:</label>
    <input type="file" name="archivos[]" multiple><br>

    <button type="submit" name="submit">Guardar Cambios</button>
</form>
</form>

    <script>
        $(document).ready(function() {
            $('#add-service').on('click', function() {
                $('#services-container').append(`
                    <div class="service-item">
                        <label>Tipo de Servicio:</label>
                        <input type="text" name="servicios[nuevo][servicio]" required>
                        
                        <label>Detalles:</label>
                        <input type="text" name="servicios[nuevo][detalles]" required>

                        <label>Precio:</label>
                        <input type="number" step="0.01" name="servicios[nuevo][monto]" required>

                        <label>Empresa/Contacto:</label>
                        <select name="servicios[nuevo][contacto_id]" required>
                            <option value="">Seleccione un contacto</option>
                            <?php while ($contact = $contacts_result->fetch_assoc()) {
                                echo "<option value='{$contact['id']}'>{$contact['nombre_empresa']}</option>";
                            } ?>
                        </select>

                        <button type="button" class="remove-service">Eliminar</button>
                    </div>
                `);
            });

            $(document).on('click', '.remove-service', function() {
                $(this).closest('.service-item').remove();
            });
        });

        // Recalcular totales
        $(document).ready(function() {
    function calcularTotales() {
        let sumServicios = 0;
        $('.monto-servicio').each(function() {
            if ($(this).val()) {
                sumServicios += parseFloat($(this).val());
            }
        });
        $('#total_general').val((parseFloat($('#total_evento').val()) + sumServicios).toFixed(2));
    }

    $('#add-service').on('click', function() {
        $('#services-container').append(`
            <div class="service-item">
                <label>Tipo de Servicio:</label>
                <input type="text" name="servicios[nuevo][servicio]" required>
                
                <label>Detalles:</label>
                <input type="text" name="servicios[nuevo][detalles]" required>

                <label>Precio:</label>
                <input type="number" step="0.01" name="servicios[nuevo][monto]" class="monto-servicio" required>

                <label>Empresa/Contacto:</label>
                <select name="servicios[nuevo][contacto_id]" required>
                    <option value="">Seleccione un contacto</option>
                    <?php while ($contact = $contacts_result->fetch_assoc()) {
                        echo "<option value='{$contact['id']}'>{$contact['nombre_empresa']}</option>";
                    } ?>
                </select>

                <button type="button" class="remove-service">Eliminar</button>
            </div>
        `);
    });

    $(document).on('click', '.remove-service', function() {
        $(this).closest('.service-item').remove();
        calcularTotales();
    });

    $(document).on('input', '.monto-servicio', calcularTotales);
    $('#total_evento').on('input', calcularTotales);

    // Inicializar totales al cargar la página
    calcularTotales();
});
    </script>
</body>
</html>
