<?php
// Conexión a la base de datos
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = ''; // Ajusta según tu configuración

// Inicializar la conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar si la conexión fue exitosa
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables para búsqueda
$search = '';
$sql = "SELECT * FROM contactos";

// Procesar búsqueda si se envía el formulario
if (isset($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']); // Escapar caracteres especiales
    $sql = "SELECT * FROM contactos WHERE nombre_empresa LIKE '%$search%' OR rubro LIKE '%$search%'";
}

// Ejecutar la consulta
$result = $conn->query($sql);

// Verificar si la consulta fue exitosa
if ($result === FALSE) {
    die("Error en la consulta: " . $conn->error);
}

// Obtener el ID del nuevo contacto y el mensaje si están presentes
$new_contact_id = isset($_GET['new_contact_id']) ? intval($_GET['new_contact_id']) : null;
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Contactos</title>
    <link rel="stylesheet" href="css/stclientes.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body>
    <?php include "includes/header.php"; ?>
    <main>
        <h1>Lista de Contactos</h1>

        <!-- Mostrar mensaje de éxito -->
        <?php if (!empty($message)): ?>
            <div class="success-message"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Barra de búsqueda -->
        <div class="search-container">
            <input type="text" id="searchTerm" placeholder="Buscar por Nombre de Empresa o Rubro" value="<?php echo htmlspecialchars($search); ?>">
            <a href="nuevo_contacto.php" class="new-contact-button">
                <img src="img/add-contacto.png" alt="Nuevo Contacto" style="width: 47px; height: auto;">
            </a>        
        </div>

        <!-- Tabla para mostrar los contactos -->
        <table border="1">
            <thead>
                <tr>
                    <th>Nombre de la Empresa</th>
                    <th>Rubro</th>
                    <th>Teléfono</th>
                    <th>Correo</th>
                    <th>Dirección</th>
                    <th>Web</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="contactosData">
                <?php if (isset($result) && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr <?php echo ($row['id'] == $new_contact_id) ? 'class="highlight"' : ''; ?>>
                            <td><?php echo htmlspecialchars($row['nombre_empresa']); ?></td>
                            <td><?php echo htmlspecialchars($row['rubro']); ?></td>
                            <td><?php echo htmlspecialchars($row['telefono']); ?></td>
                            <td><?php echo htmlspecialchars($row['correo']); ?></td>
                            <td><?php echo htmlspecialchars($row['direccion']); ?></td>
                            <td><?php echo htmlspecialchars($row['web']); ?></td>
                            <td>
                                <a href="authenticate2.php?redirect=cont_edit.php?id=<?php echo $row['id']; ?>" class="action-button edit">Editar</a>
                                <a href="authenticate2.php?redirect=cont_delete.php?id=<?php echo $row['id']; ?>" class="action-button delete" onclick="return confirm('¿Estás seguro de que quieres eliminar este contacto?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No se encontraron contactos.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>

    <script>
        $(document).ready(function() {
            $('#searchTerm').on('input', function() {
                var searchValue = $(this).val().toLowerCase();
                $('#contactosData tr').each(function() {
                    var rowText = $(this).text().toLowerCase();
                    $(this).toggle(rowText.indexOf(searchValue) !== -1);
                });
            });
        });
    </script>
</body>
</html>
